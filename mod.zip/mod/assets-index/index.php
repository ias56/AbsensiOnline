<?php

header("location: /");
?>