<?php

// Hak cipta 2023
// sigit prastiya

header("location: /");
?>